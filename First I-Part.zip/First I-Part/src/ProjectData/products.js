const Products = [
     {
       "id": 1,
       "name": "Product 1",
       "description": "Description for Product 1.",
       "price": 19.99,
       "image": require("../images/product1.jpg")
     },
     {
       "id": 2,
       "name": "Product 2",
       "description": "Description for Product 2.",
       "price": 29.99,
       "image": require("../images/product2.jpg")
     },
     {
       "id": 3,
       "name": "Product 3",
       "description": "Description for Product 3.",
       "price": 39.99,
       "image": require("../images/product3.jpg")
     },
     {
       "id": 4,
       "name": "Product 4",
       "description": "Description for Product 4.",
       "price": 49.99,
       "image": require("../images/product4.jpg")
     },
     {
       "id": 5,
       "name": "Product 5",
       "description": "Description for Product 5.",
       "price": 59.99,
       "image": require("../images/product5.jpg")
     },
     {
       "id": 6,
       "name": "Product 6",
       "description": "Description for Product 6.",
       "price": 69.99,
       "image": require("../images/product6.jpg")
     },
     {
       "id": 7,
       "name": "Product 7",
       "description": "Description for Product 7.",
       "price": 79.99,
       "image": require("../images/product7.jpg")
     },
     {
       "id": 8,
       "name": "Product 8",
       "description": "Description for Product 8.",
       "price": 89.99,
       "image": require("../images/product8.jpg")
     },
     {
       "id": 9,
       "name": "Product 9",
       "description": "Description for Product 9.",
       "price": 99.99,
       "image": require("../images/product9.jpg")
     },
     {
       "id": 10,
       "name": "Product 10",
       "description": "Description for Product 10.",
       "price": 109.99,
       "image": require("../images/product10.jpg")
     },
     {
       "id": 11,
       "name": "Product 11",
       "description": "Description for Product 11.",
       "price": 119.99,
       "image": require("../images/product11.jpg")
     },
     {
       "id": 12,
       "name": "Product 12",
       "description": "Description for Product 12.",
       "price": 129.99,
       "image": require("../images/product12.jpg")
     },
     {
       "id": 13,
       "name": "Product 13",
       "description": "Description for Product 13.",
       "price": 139.99,
       "image": require("../images/product13.jpg")
     },
     {
       "id": 14,
       "name": "Product 14",
       "description": "Description for Product 14.",
       "price": 149.99,
       "image": require("../images/product14.jpg")
     },
     {
       "id": 15,
       "name": "Product 15",
       "description": "Description for Product 15.",
       "price": 159.99,
       "image": require("../images/product15.jpg")
     },
     {
       "id": 16,
       "name": "Product 16",
       "description": "Description for Product 16.",
       "price": 169.99,
       "image": require("../images/product16.jpg")
     },
     {
       "id": 17,
       "name": "Product 17",
       "description": "Description for Product 17.",
       "price": 179.99,
       "image": require("../images/product17.jpg")
     },
     {
       "id": 18,
       "name": "Product 18",
       "description": "Description for Product 18.",
       "price": 189.99,
       "image": require("../images/product18.jpg")
     },
     {
       "id": 19,
       "name": "Product 19",
       "description": "Description for Product 19.",
       "price": 199.99,
       "image": require("../images/product19.jpg")
     },
     {
       "id": 20,
       "name": "Product 20",
       "description": "Description for Product 20.",
       "price": 209.99,
       "image": require("../images/product20.jpg")
     }
   ]


export default Products